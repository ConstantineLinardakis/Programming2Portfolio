import prefix
import suffix
import root

print("Welcome to the random word generator!","Enter 'r' if you want to get random word, or enter 'c' to choose a word : ")
myWord = input("")

if myWord = 'c':
    c = int(input("Print the word you want -"))




    #p = prefix.prefix(l,w,h)
    #print(p.calcvolume())
    #print(p.calcsurface())

elif myWord == 'random':
    r = int(print("Here is your random word -"))



    #s = root.root(r)
    #print(s.calcvolume())
    #print(s.calcsurface())




question = input('Would you like to play the game again?, Yes or No: ')
if question == 'Yes':
  print("Okay go again.")
  exit

elif question == 'No':
  print("Okay hoped you had fun.")
