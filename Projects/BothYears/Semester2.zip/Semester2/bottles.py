#loop

bottles = 99
while (bottles > 0):
    if (bottles > 1):
        print bottles, "bottles of root beer on the wall", bottles, "bottles of root beer"
        print "Take one down pass it around,", bottles, "bottles of root beer on the wall"
        
        
    else:
        print bottles, "bottles of root beer on the wall", bottles, "bottle of root beer"

    bottles = bottles - 1
  



    
   