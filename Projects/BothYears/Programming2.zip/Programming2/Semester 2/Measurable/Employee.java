/*
  An Employee represents a employees wage.
*/

public class Employee implements Measurer
{

  private double anualWage;
  private double wageWithBenefits;

  /**
     Constructs an Employee.
     @param anual wage of the employee's pay.
     @param benefts of wage.
  */

  public Employee (double anual, double wageBenefit)
  {
    anualWage = anual;
    wageWithBenefits = wageBenefit;
  }

  public double getMeasure()
  {
    return anualWage - wageWithBenefits;
  }

}
