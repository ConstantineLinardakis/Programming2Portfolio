/*
   Program tests the Measurer Item Class
*/

public class MeasurerTester
{
  public static void main(String[] args)
  {
    Measurer snack = new Item(5,10);
    System.out.printf("Theater popcorn: %.2f%n", snack.getMeasure());

    Measurer cereal = new Item(5.95, 1.15);
    System.out.printf("Cereal: %.2f%n", cereal.getMeasure());

    Measurer employeeOne = new Employee(1000,100);
    System.out.printf("Employee One Cash Benefits: %.2f%n", employeeOne.getMeasure());

    Measurer employeeTwo = new Employee(2000,500);
    System.out.printf("Employee Two Cash Benefits: %.2f%n", employeeTwo.getMeasure());
  }
}
