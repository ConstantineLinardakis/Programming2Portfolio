public class RandomPlayer(){

  public RandomPlayer(){
    this.rand = new Random();
    this.start = false;
    this.player = 0;
  }

  public boolean getStartingPlayer(){
    return player;
  }
   public boolean calculateRand(){
     return start
   }
}
