public class TicTacToeRunner(){

  public TicTacToeRunner(boolean turn){
    this.win = false;
    this.moves = 0;
    this.turn = turn;
  }

  public int checkMove(){
    return moves;
  }
  public void readBoard(){

  }
  public void printWinner(){

  }
  public boolean getPTurn(){
    return turn;
  }
  public boolean checkGame(){
    return win;
  }
  public void board(){

  }
  public void updateBoard(){

  }

}
