public class Player(){


  public Player(int playerMove){
    this.playerMove = playerMove;
    this.x = 'X';
    this.o = 'O';
  }

  public void move(){

  }

  private int checkPlayerMoves(){
    return playerMove;
  }

}
