import java.util.Scanner;

public class HumanPlayer(){

  public HumanPlayer(int space){
    this.checkChar = false;
    this.space = space;
  }

  public boolean checkSpace(int space){
    return checkChar;
  }

  public char getInput(){
    Scanner input = new Scanner(System.in);
    return space;
  }

}
