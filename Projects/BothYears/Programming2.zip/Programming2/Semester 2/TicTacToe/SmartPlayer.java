public class SmartPlayer(){

  public SmartPlayer(){
    this.spaceNumber = 0;
  }

  public int calculateMove(){
    return spaceNumber;
  }

}
