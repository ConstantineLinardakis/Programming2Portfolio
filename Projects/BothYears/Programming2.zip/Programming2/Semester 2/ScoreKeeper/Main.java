import java.util.Scanner;
import java.util.Random;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Main {
  public static void main(String[] args) throws FileNotFoundException {

    String scores = "";

    PrintWriter out = new PrintWriter(scores);

    Scanner inputScanner = new  (System.in);
    String userInput = "";
      do {
           play();
           System.out.print("Do you want to play again ([Y] / n)? ");
           userInput = inputScanner.nextLine();
           System.out.println(userInput);
      } while (userInput.equals("Y") || userInput.equals(""));

    out.close();

  }
}
