import java.util.Scanner;

public class DayTester
{
   public static void main(String[] args)
   {
     System.out.println("DayTester - ConstantineLinardakis");
     Scanner scan = new Scanner(System.in);

     Day today = new Day();
  

     System.out.println("Please enter a custom year you would like to test :");
     int year = scan.nextInt();
     System.out.println("Please enter a custom month you would like to test :");
     int month = scan.nextInt();
     System.out.println("Please enter a custom day you would like to test :");
     int day = scan.nextInt();



     Day myBirthday = new Day(year , month , day); //Jan 11 2005
     int daysAlive = today.daysFrom(myBirthday);
     System.out.println("Days Alive : " + daysAlive);

   }
}
