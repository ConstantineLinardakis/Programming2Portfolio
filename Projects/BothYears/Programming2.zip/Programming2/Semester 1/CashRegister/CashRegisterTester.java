/**
   This class tests the CashRegister class.
*/
public class CashRegisterTester{
  public static void main(String[] args) {
      CashRegister register = new CashRegister();

      System.out.println("----------------------------------------------------------------- ");
      System.out.println("BELOW IS ENTERED AMOUNT WITH PURCHASE AND RECEIVING PAYMENT : ");
      System.out.println("----------------------------------------------------------------- ");

      register.recordPurchase(2.25);
      register.recordPurchase(19.25);
      register.receivePayment(23, 2, 0, 0, 0);
      System.out.print("Change: " + register.giveChange());
      System.out.println(" Expected: 2.0");


      System.out.println("----------------------------------------------------------------- ");
      System.out.println("BELOW IS DOLLARS, PENNIES, DIMES, NICKELS, QUARTERS ENTERED IN : ");
      System.out.println("----------------------------------------------------------------- ");

      register.enterDollars(20);
      register.enterPennies(10);
      register.enterDimes(5);
      register.enterNickels(3);
      register.enterQuarters(1);
      System.out.print("Change: " + register.giveChange());
      System.out.println(" Expected: 39.0");
  }
}
