
public class EnumTest {
  public static void main(String[]args){

      public enum CardValues{ TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGTH, NINE, TEN, JACK, QUEEN, KING, ACE}

      CardValues two = CardValues.TWO;

      if(two == CardValues.TWO) {
      System.out.println("2");
    }
  }
}
