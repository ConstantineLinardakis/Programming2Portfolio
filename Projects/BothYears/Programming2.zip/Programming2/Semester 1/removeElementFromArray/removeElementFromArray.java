import java.util.Arrays;

class removeElementFromArray {
  public static void main(String[] args){

    System.out.println("\n");

    int[] array = { 10, 20, 30, 40, 50 };
    System.out.println("Original Array: " + Arrays.toString(array));

    int index = 2;
    System.out.println("Index Used to Remove Element : " + index);

    int[] newArr = new int[array.length - 1];
    for(int j=0, k=0; j<array.length; j++) {
            if(j == index)
                continue;

            newArr[k++] = array[j];
        }


        System.out.println("After removing an element,  new Array : ");
        for (int l=0; l<newArr.length; l++) {
            System.out.print(newArr[l] + " ");
    }
    System.out.println("\n");
  }
}
