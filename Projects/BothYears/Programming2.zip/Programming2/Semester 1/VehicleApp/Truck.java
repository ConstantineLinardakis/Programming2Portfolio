public class Truck extends Vehicle{

  // Instance variables added to subclass
  private String licensePlateNumber;
  private String truckColor;
  private int topSpeed;

  public Truck(){
    // Using a super class instance variable
    setNumberOfTires(4);
    setNumberOfDoors(4);
    setNumberOfSeats(5);
    licensePlateNumber = "??????";
    truckColor = "??????";
    topSpeed = 0;
  }

  // This method is added to the subclass (licenseplate of car)
  public void setLicensePlateNumber(String newValue){
    licensePlateNumber = newValue;
  }

  // This method is added to the subclass (color of car)
  public void setTruckColor(String newColor){
    truckColor = newColor;
  }

  // This method is added to the subclass (top speed of car)
  public void setTopSpeed(int newTopSpeed){
    topSpeed = newTopSpeed;
  }

  // This method overrides a method from the superclass
  public String getDescription(){
    return "A truck with license plate " + licensePlateNumber + " and the color of the truck is, " + truckColor + "." + " The truck also has a top speed of : " + topSpeed;
  }
}
