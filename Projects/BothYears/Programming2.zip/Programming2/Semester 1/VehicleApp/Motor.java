public class Motor extends Vehicle{

  // Instance variables added to subclass
  private String licensePlateNumber;
  private String motorColor;
  private int topSpeed;

  public Motor(){
    // Using a super class instance variable
    setNumberOfTires(2);
    setNumberOfDoors(0);
    setNumberOfSeats(2);
    licensePlateNumber = "??????";
    motorColor = "??????";
    topSpeed = 0;
  }

  // This method is added to the subclass (licenseplate of car)
  public void setLicensePlateNumber(String newValue){
    licensePlateNumber = newValue;
  }

  // This method is added to the subclass (color of car)
  public void setMotorColor(String newColor){
    motorColor = newColor;
  }

  // This method is added to the subclass (top speed of car)
  public void setTopSpeed(int newTopSpeed){
    topSpeed = newTopSpeed;
  }

  // This method overrides a method from the superclass
  public String getDescription(){
    return "A motor with license plate " + licensePlateNumber + " and the color of the motor is, " + motorColor + "." + " The motor also has a top speed of : " + topSpeed;
  }
}
