public class Vehicle{

  // Instance variables for Super Class
  private int numberOfTires;
  private int numberOfDoors;
  private int numberOfSeats;

  // Getting & settings the tires of the vehicle.
  public int getNumberOfTires() {
    return numberOfTires;
  }

  public void setNumberOfTires(int newValue){
    numberOfTires = newValue;
  }

  // Getting & settings the doors of the vehicle.
  public int getNumberOfDoors() {
    return numberOfDoors;
  }

  public void setNumberOfDoors(int newDoor){
    numberOfDoors = newDoor;
  }

  // Getting & settings the seats of the vehicle.
  public int getNumberOfSeats() {
    return numberOfSeats;
  }

  public void setNumberOfSeats(int newSeat){
    numberOfSeats = newSeat;
  }

  // Getting the description of the vehicle.
  public String getDescription(){
    return "A vehicle with " + numberOfTires + " tires, and also has about " + numberOfDoors + " doors and " + numberOfSeats + " seats.";
  }
}
