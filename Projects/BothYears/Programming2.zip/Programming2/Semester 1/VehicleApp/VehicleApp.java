/*
* @author Constantine Linardakis
* @since Jan/6th/2020
* This inheritance app, will get the type of vehicles and print the amount of seats,doors,tires, etc. (Hard coded)
*/

public class VehicleApp {

  // Car Constructor
  public static void print(Car c){
    System.out.println(c.getDescription());
    System.out.println("Consist of " + c.getNumberOfTires() + " tires, and " + c.getNumberOfDoors() + " doors and " + c.getNumberOfSeats() + " seats.");
  }

  // Truck Constructor
  public static void print(Truck t){
    System.out.println(t.getDescription());
    System.out.println("Consist of " + t.getNumberOfTires() + " tires, and " + t.getNumberOfDoors() + " doors and " + t.getNumberOfSeats() + " seats.");
  }

  // Motor Constructor
  public static void print(Motor m){
    System.out.println(m.getDescription());
    System.out.println("Consist of " + m.getNumberOfTires() + " tires, and " + m.getNumberOfDoors() + " doors and " + m.getNumberOfSeats() + " seats.");
  }

  public static void main(String[] args) {

    // Printing a car without any set's.
    Car aPlainCar = new Car();
    print(aPlainCar);

    // Printing a Limo
    Car aLimo = new Car();
    aLimo.setLicensePlateNumber("LIMO123");
    aLimo.setCarColor("RED");
    aLimo.setNumberOfTires(8);
    aLimo.setNumberOfDoors(6);
    aLimo.setNumberOfSeats(10);
    aLimo.setTopSpeed(95);
    print(aLimo);

    // Printing a Truck without any set's.
    Truck aPlainTruck = new Truck();
    print(aPlainTruck);

    // Printing a semi truck.
    Truck aSemi = new Truck();
    aSemi.setLicensePlateNumber("SEMI123");
    aSemi.setTruckColor("WHITE");
    aSemi.setNumberOfTires(10);
    aSemi.setNumberOfDoors(2);
    aSemi.setNumberOfSeats(3);
    aSemi.setTopSpeed(75);
    print(aSemi);

    // Printing a Motor without any set's.
    Motor aPlainMotor = new Motor();
    print(aPlainMotor);

    // Printing a semi truck.
    Motor aMotorCycle = new Motor();
    aMotorCycle.setLicensePlateNumber("MOTOR123");
    aMotorCycle.setMotorColor("GOLD");
    aMotorCycle.setNumberOfTires(2);
    aMotorCycle.setNumberOfDoors(0);
    aMotorCycle.setNumberOfSeats(2);
    aMotorCycle.setTopSpeed(150);
    print(aMotorCycle);
  }
}
