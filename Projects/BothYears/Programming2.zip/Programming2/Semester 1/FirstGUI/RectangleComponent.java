import java.awt.Font;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Line2D;
import javax.swing.JComponent;

public class RectangleComponent extends JComponent{
  public void paintComponent(Graphics g) {

    // Year, today
    Day today = new Day();
    int year = today.getYear();

    // Birthday's
    Day myBirthday = new Day(year, 1, 11);  //Jan 11
    Day momBday = new Day(year , 8, 9);  //Aug 09
    Day micBday = new Day(year , 8, 27);  //Aug 27
    Day dadBday = new Day(year - 1, 12, 12);  //Dec 12

    // Day Birthday's
    int costa = today.daysFrom(myBirthday);
    int mom = 365 - today.daysFrom(momBday);
    int mic = 365 - today.daysFrom(micBday);
    int dad = 365 - today.daysFrom(dadBday);

    // Recover Graphics2D
    Graphics2D g2 = (Graphics2D) g;

    // Color Set 1
    Color DARK_GRAY = new Color(64,64,64);
    g2.setColor(Color.DARK_GRAY);

    // Costa/Ang Rectangle
    Rectangle mine = new Rectangle(160, 550 - costa - 130, 40, costa);  // Jan - 11 40
    g2.draw(mine);
    g2.fill(mine);
    Rectangle ang = new Rectangle(228,550 - costa - 130, 40, costa);  // Jan - 11
    g2.draw(ang);
    g2.fill(ang);
    // Connie Rectangle
    Rectangle connie = new Rectangle(300,550 - mom - 130,40,mom);  // Aug - 09
    g2.draw(connie);
    g2.fill(connie);
    // Michaelis Rectangle
    Rectangle michaelis = new Rectangle(380,550 - mic - 130,40,mic);  // Aug - 27
    g2.draw(michaelis);
    g2.fill(michaelis);
    // Niko Rectangle
    Rectangle niko = new Rectangle(449,550 - dad - 130,40,dad); // Dec - 12
    g2.draw(niko);
    g2.fill(niko);

    // Color Set 2
    Color BLACK = new Color(0,0,0);
    g2.setColor(Color.BLACK);

    // Text
    g2.drawString("Family's Birthday",245,50);
    g2.drawString("365",95,90);
    g2.drawString("0",110,420);
    g2.drawString("Costa",160,440);
    g2.drawString("Angelina",220,440);
    g2.drawString("Connie",300,440);
    g2.drawString("Michaelis",370,440);
    g2.drawString("Niko",455,440);

    // Color Set 3
    Color WHITE = new Color(255,255,255);
    g2.setColor(Color.WHITE);

    // Text 2
    g2.drawString(String.valueOf(costa),168,186);
    g2.drawString(String.valueOf(costa),238,186);
    g2.drawString(String.valueOf(mom),308,110);
    g2.drawString(String.valueOf(mic),388,100);
    g2.drawString(String.valueOf(dad),460,360);

    // Color Set 4
    Color RED = new Color(255,0,0);
    g2.setColor(Color.RED);

    // Lines
    Line2D.Double segment = new Line2D.Double(120,80,120,420);
    Line2D.Double segment2 = new Line2D.Double(120,420,500,420);
    g2.draw(segment);
    g2.fill(segment);
    g2.draw(segment2);
    g2.fill(segment2);

    // Made by - Constantine Linardakis
    // I was looking for a way to make a calculator then have it display the text
    // but I couldn't find a way so I hardcoded it.

    // Link for help : https://bookshelf.vitalsource.com/#/books/9781119499091/cfi/6/128!/4/2/2/2@0:0
    //Terminal : ls, cd, javac, java
  }
}
