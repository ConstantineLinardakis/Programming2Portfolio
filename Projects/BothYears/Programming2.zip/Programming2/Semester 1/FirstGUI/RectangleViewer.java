import javax.swing.*;


public class RectangleViewer{
  public static void main(String[] args) {

    // Creating new "Main Frame"
    JFrame frame = new JFrame();
    frame.setSize(600,550);
    frame.setTitle("Family Birthday");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    // Adding the new Frame Component
    RectangleComponent component = new RectangleComponent();
    frame.add(component);

    // Setting the frame to "Visible"
    frame.setVisible(true);

  }
}
