import java.util.*;

public class swapTwoElement {
  public static void main(String[] args){

    ArrayList<String> list = new ArrayList<String>();
    list.add("1");
    list.add("2");
    list.add("3");
    list.add("4");

    System.out.println(" Old List : \n " + list);

    Collections.swap(list, 1, 2);

    System.out.println(" New List : \n " +  list);
  }
}
