import java.awt.Rectangle;

public class CopyDemo{
  public static void main(String[] args){
    Rectangle box = new Rectangle(5,10,20,30);
    Rectangle box2 = box; // Reference <- Term

    System.out.println("box:" + box);
    System.out.println("box2:" + box2);

    box2.translate(15,15);

    System.out.println("box:" + box);
    System.out.println("box2:" + box2);

    int luckyNumber = 13;
    int luckyNumber2 = luckyNumber;

    // Mutators <- Learn
    
    System.out.println("LuckyNumber:" + luckyNumber);
    System.out.println("LuckyNumber 2:" + luckyNumber2);

    luckyNumber2 = 12;

    System.out.println("LuckyNumber:" + luckyNumber);
    System.out.println("LuckyNumber 2:" + luckyNumber2);

  }
}
