public class CounterDemo {
  public static void main(String[] args){

    /**
    *   This is the main method.
    *   @param args Unused.
    *   @return Nothing.
    *   @exception IOException.
    *   @see IOException.
    */

    /**
    *   This is the first tally test using a custom tally.
    *   It should return the value of 5.
    */
    
    Counter custTally = new Counter(100);
    custTally.reset();
    custTally.click();
    custTally.click();
    custTally.click();
    custTally.click();
    custTally.undo();
    custTally.click();
    custTally.click();
    int result2 = custTally.getValue();
    System.out.println("Value of Custom Tally : " + result2);

    /**
    *   This is the second tally test using tally.
    *   It should return the value of 2.
    */

    Counter tally = new Counter();
    tally.click();
    tally.click();
    tally.click();
    tally.undo();
    int result = tally.getValue();
    System.out.println("Value : " + result);
  }
}
