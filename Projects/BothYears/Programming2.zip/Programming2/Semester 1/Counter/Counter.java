/**
*    Prints a value of the total tally's created with click,reset,undo.
*    @author ConstantineLinardakis
*    @since 2020-09-30
*/


public class Counter {
  private int value;   //Private is hiding data inside the public class

  /**
  *    Default Constructor
  */

  public Counter() {
    value = 0;
  }

  /**
  *    2nd Constructor for passing in an int
  *    This method is used to set the initialValue.
  *    @param initialValue is used for the value of the tally's.
  */

  public Counter(int initialValue) {
    value = initialValue;
  }


  /**
  *    This method is used to get the value of tally's.
  *    @return the current value. This returns the sum of 0.
  */

  public int getValue() {
    return value;
  }

  /**
  *    Adds to the value.
  */

  public void click() {
    value += 1;
  }

  /**
  *    Subtracts from the value.
  */

  public void undo() {
    value -= 1;
  }

  /**
  *    Sets the value.
  */

  public void reset() {
    value = 0;
  }

}
