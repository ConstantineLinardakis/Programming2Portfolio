import java.util.Arrays;

class insertAnElement {
  public static void main(String[] args) {

      int[] array = {1, 5, 10, 15, 20, 25};

      int Index_position = 2;
      int newValue = 5;

      System.out.println("Original Array : " + Arrays.toString(array));

      for(int i=array.length-1; i > Index_position; i--){
        array[i] = array[i-1];
      }
      array[Index_position] = newValue;
      System.out.println(" New Array : " + Arrays.toString(array));
  }
}
